import React from 'react';
import ReactDOM from 'react-dom';

import CryptoCcyList from './components/CryptoCcyList';

function initialise() {
    
    ReactDOM.render(<CryptoCcyList/>, document.getElementById('myApp-root'));
}

initialise();