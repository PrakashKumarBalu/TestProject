module.exports = {
    currencyList : [
        { value: 'SGD', name: 'SGD' },
        { value: 'AUD', name: 'AUD' },
        { value: 'EUR', name: 'EUR' },
        { value: 'GBP', name: 'GBP', isDefault: true },
        { value: 'USD', name: 'USD' },
        { value: 'VND', name: 'VND' }

    ]
}