import React from 'react';

const css = require('./Dropdown.css');

export default class Dropdown extends React.Component {
    constructor() {
        super();
    }
    changeHandler(event) {

        if (typeof this.props.onChange === 'function') {
            this.props.onChange(event);
        }
    }
     getDefaultOption(){
        if(this.props.defaultValue) {
            return this.props.defaultValue;
        } else{
            let optionList =this.props.options,
            defaultValue = optionList[0].value;
        
            for (let i = 0; i < optionList.length; i++) {
                
                if(optionList[i].isDefault){
                    
                    return optionList[i].value;
                }
            }
            return defaultValue;
        } 
    }
    render() {
        
        return (
            <div>
                <select className={`form-control ${css.myAppSelect}`} onChange={this.changeHandler.bind(this)} value={this.getDefaultOption()}>
                    {this.props.options && this.props.options.length > 0 && this.props.options.map(function (option, index) {

                        return (<option key={index} value={option.value}> {option.name} </option>)
                    })}
                </select>
            </div>
        )
    }
}
