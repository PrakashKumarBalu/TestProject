import React from 'react';
import ReactDOM from 'react-dom'

import { getCryptoData } from '../api/api';


import Dropdown from './common/Dropdown/Dropdown'
import CurrencyList from './CurrencyList'

import ListOfCurrencies from './ListOfCurrency.js';

const css = require('./CryptoCcyList.css');

const currencyList = ListOfCurrencies.currencyList;


export default class CryptoCcyList extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            dataFetched: false,
            selectedCurrency: this.getDefaultCurrency()
        };
    }

    componentDidMount() {
        this.getCryptoCurrencyList(this.state.selectedCurrency);
    }

    getDefaultCurrency() {

        let defaultCurrency = currencyList[0].value;

        for (let i = 0; i < currencyList.length; i++) {

            if (currencyList[i].isDefault) {

                return currencyList[i].value;
            }
        }
        return defaultCurrency;
    }

    getCryptoCurrencyList(selectedCurrency) {
        getCryptoData(selectedCurrency).then(data => {
            this.setState({
                currencyList: data,
                selectedCurrency: selectedCurrency
            });
        })

    }

    currencyDropdownChangeHandler(event) {

        this.getCryptoCurrencyList(event.target.value);

    };


    render() {
        return (
            <div>
                <div className={`row ${css.myApphomeheader}`} >
                    <div className={`col-md-8 ${css.myApphometitle}`} >
                        Top 5 CryptoCurrency
                    </div>
                    <div className="col-md-4">
                        <Dropdown defaultValue={this.state.selectedCurrency} options={currencyList} onChange={this.currencyDropdownChangeHandler.bind(this)} />
                    </div>
                </div>
                <CurrencyList selectedCurrency={this.state.selectedCurrency} currencyList={this.state.currencyList} />
            </div>
        );
    }

}
