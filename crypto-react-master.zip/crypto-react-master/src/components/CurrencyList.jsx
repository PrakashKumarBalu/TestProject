import React from 'react';
import numeral from 'numeral';



import { getCryptoData } from '../api/api';


const css = require('./CryptoCcyList.css');


export default class CurrencyList extends React.Component {
    constructor() {
        super();
    }

    
    render() {
       

        

        let currencyPlaceholder = this.props.selectedCurrency,
            selectedCurrency = this.props.selectedCurrency;
        
            if(currencyPlaceholder){
                currencyPlaceholder =currencyPlaceholder.toLowerCase();  
            }
        return (
            <div>
                {this.props.currencyList && this.props.currencyList.length > 0 && this.props.currencyList.map(function (crypto, index) {

                    return (<div key={index} className={"row "+ (css.myAppCurrencyRow)  + " " + (index%2 == 0 ? (css.myAppOddRow): (css.myAppEvenRow)) }> 
                        <div className={`col-md-3 ${css.myAppCoinName}`}>
                            {crypto.name}
                        </div>
                        <div className="col-md-6 text-right"> 
                            <span className={css.myAppCurrencySymbol}>{selectedCurrency} </span> 
                          
                            {`${numeral(crypto['price_' + currencyPlaceholder]).format('0,0.00')}`}
                        </div>

                       <div className={"col-md-3 text-right " + (crypto.percent_change_24h.indexOf('-')>-1 ? (css.myAppColorRed) : (css.myAppColorGreen))}>
                            {`${crypto.percent_change_24h}%`} 
                        </div>
                    </div>)
                })}


            </div>
        )
    }
}