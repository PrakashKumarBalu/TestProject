import React from 'react';
import ReactDOM from 'react-dom';


import { connect } from 'react-redux';
import {getCryptoCurrencyList}  from '../actions/currencyActions'

import { Provider } from 'react-redux';
import store from '../store'



import Dropdown from './common/Dropdown/Dropdown'
import CurrencyList from './CurrencyList'

import ListOfCurrencies from '../ListOfCurrency.js';

const css = require('./CryptoCcyList.css');


const currencyList = ListOfCurrencies.currencyList;

var commonUtils = require('../common/utils')


class CryptoCcyList extends React.Component {
    

    componentWillMount() {
        
        this.props.getCryptoCurrencyList(commonUtils.getDefaultOption(currencyList));
    }


    currencyDropdownChangeHandler(event) {

        this.props.getCryptoCurrencyList(event.target.value);

    };


    render() {
        return (
            
            <div>
                <div className={`row ${css.myApphomeheader}`} >
                    <div className={`col-md-8 ${css.myApphometitle}`} >
                        Top 5 CryptoCurrency
                    </div>
                    <div className="col-md-4">
                        <Dropdown defaultValue={this.props.selectedCurrency} options={currencyList} onChange={this.currencyDropdownChangeHandler.bind(this)} />
                    </div>
                </div>
                <CurrencyList selectedCurrency={this.props.selectedCurrency} currencyList={this.props.currencyList} />
            </div>
          
        );
    }

}

const mapStateToProps = state => ({
    currencyList: state.currency.currencyList,
    selectedCurrency: state.currency.selectedCurrency

})

export default connect (mapStateToProps, { getCryptoCurrencyList })(CryptoCcyList);
