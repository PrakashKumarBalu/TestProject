import React from 'react';

const css = require('./Dropdown.css');

var CommonUtils = require('../../../common/utils');

export default class Dropdown extends React.Component {
    constructor() {
        super();
    }
    changeHandler(event) {

        if (typeof this.props.onChange === 'function') {
            this.props.onChange(event);
        }
    }
     getDefaultOption(){
        if(this.props.defaultValue) {
            return this.props.defaultValue;
        } else{
            
            return CommonUtils.getDefaultOption(this.props.optionList);
        }  
    }
    render() {
       
        return (
            <div>
                <select className={`form-control ${css.myAppSelect}`} onChange={this.changeHandler.bind(this)} value={this.getDefaultOption()}>
                    {this.props.options && this.props.options.length > 0 && this.props.options.map(function (option, index) {

                        return (<option key={index} value={option.value}> {option.name} </option>)
                    })}
                </select>
            </div>
        )
    }
}
