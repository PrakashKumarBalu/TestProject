export function getDefaultOption(optionList) {
    for (let i = 0; i < optionList.length; i++) {
        if(optionList[i].isDefault){
            return optionList[i].value;
        }
    }
    return optionList[0].value;
}

