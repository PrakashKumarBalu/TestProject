import { FETCH_CURRENCY } from '../actions/types';

import ListOfCurrencies from '../ListOfCurrency.js';

var CommonUtils = require('../common/utils');


const initialState = {
    selectedCurrency: CommonUtils.getDefaultOption(ListOfCurrencies.currencyList),
    currencyList: []
}



export default function(state= initialState, action){

    switch(action.type) {
        case FETCH_CURRENCY:
            
            return { 
                state,
                currencyList: action.currencyList,
                selectedCurrency: action.selectedCurrency
            }
        default: 
            return state;
    }
}

