import React from 'react';
import ReactDOM from 'react-dom';

import { Provider } from 'react-redux';
import store from './store'

import CryptoCcyList from './components/CryptoCcyList';

function initialise() {
    
    ReactDOM.render(
        <Provider store={store}> 
            <CryptoCcyList/> 
        </Provider>, document.getElementById('myApp-root'));
}

initialise();