module.exports = {
    currencyList : [
        { value: 'SGD', name: 'SGD' },
        { value: 'AUD', name: 'AUD' },
        { value: 'EUR', name: 'EUR' },
        { value: 'GBP', name: 'GBP', isDefault: false },
        { value: 'USD', name: 'USD' , isDefault: true },
        { value: 'VND', name: 'VND' }

    ]
}