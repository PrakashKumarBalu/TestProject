import { FETCH_CURRENCY } from './types';

export const GET_CRYPTOCCY_DATA = 'https://api.coinmarketcap.com/v1/ticker/?limit=5&convert=';

import ListOfCurrencies from '../ListOfCurrency.js';


export const getCryptoCurrencyList = (selectedCurrency) => dispatch =>  {

        fetch(`${GET_CRYPTOCCY_DATA}${selectedCurrency}`, { method: 'GET' })
            .then(res => res.json())
            .then(currencyList => dispatch({
                type: 'FETCH_CURRENCY',
                currencyList: currencyList,
                selectedCurrency: selectedCurrency
            }))
            //ToDo: Error Handling
            //ToDO: Loading indicator
            
   
}